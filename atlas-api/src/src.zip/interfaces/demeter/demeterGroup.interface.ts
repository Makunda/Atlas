export interface DemeterGroup {
    id: number;
    name: string;
    application: string;
    numObjects: number;
}