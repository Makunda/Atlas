<template>
  <v-container>
    <v-row class="text-center">
      <v-col cols="6">
        <v-card height="200"></v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.extend({
  name: "MainDashboard",

  data: () => ({})
});
</script>
