export interface ModuleGroup {
  id: number;
  name: string;
  application: string;
  numObjects: number;
  demeterGroup: boolean;
}
