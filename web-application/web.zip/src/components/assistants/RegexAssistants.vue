<template>
  <v-card min-height="300px" class="pa-3" disabled>
    <v-card-title> Regex Assistants ( Coming in next release )</v-card-title>
    <v-card-subtitle
      >Separate the objects in the applications matching theses
      rules.</v-card-subtitle
    >
    <v-card-text>
      <v-container>
        <v-row width="100%"> </v-row>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.extend({
  name: "RegexAssistants",

  data: () => ({})
});
</script>
