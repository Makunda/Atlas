export default interface IGroupResult {
  idGroup: number;
  objectConcerned: number;
  name: string;
  description: string;
}
