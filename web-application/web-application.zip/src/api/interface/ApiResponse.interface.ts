export interface ApiResponse {
  data: Record<string, any>;
  message: string;
}
