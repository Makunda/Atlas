export interface CandidateResults {
  application: string;
  tags: string[];
  numTags: number;
}
