export interface IFrameworkAssistant {
  id: number;
  started: boolean;
  category: string;
  actions: string[];
}
