export enum DetectionStatus {
  Pending,
  Success,
  Failure,
  Unknown
}
