export interface DetectionCandidate {
  application: string;
  language: string[];
}
