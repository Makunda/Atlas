<template>
  <v-container>
    <v-row class="text-center pa-5">
      <h3 class="text-h3">This is page is under construction</h3>
    </v-row>
  </v-container>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.extend({
  name: "ArchitectureExplorer",

  data: () => ({})
});
</script>